package ch02;

public class Spec02 {
/* 응용문제01 */
/*
 	오늘의 날씨 : '의'출력 후 tab키 추가한 효과
	오늘 추운데 : '오늘' 출력 후 줄바꿈
	대박 "추워" : 출력
*/
	
public static void main(String[] args) {
		System.out.println("오늘의\t날씨");
		System.out.println("오늘\n추운데");
		System.out.println("대박 \"추워\"");
	}

}
