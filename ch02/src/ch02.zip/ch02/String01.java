package ch02;

public class String01 {
	public static void main(String[] args) {
		String name = "차은우";
		String hi = "안녕 !!!!";
		// 문자열 + 문자열 = 문자열
		String greeting = name + hi;
		System.out.println(name);
		System.out.println(hi);
		System.out.println(greeting);

	}
}
