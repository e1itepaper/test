package ch02;

public class Spec01 {

	public static void main(String[] args) {
		System.out.println("대박\n사건");
		System.out.println("대박\t사건");
		System.out.println("대박\"사건"); // \" : "를 출력
		System.out.println("대박\\사건"); // \\: \를 출력
		// \(역슬래시)뒤의 특수문자는 문자로 인식
		
	}

}
