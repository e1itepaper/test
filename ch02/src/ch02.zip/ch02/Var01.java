package ch02;

public class Var01 {

	public static void main(String[] args) {
		int i1 = 7;
		System.out.println(i1);
		byte b1 = 26; //-128 ~127
		System.out.println(b1);
	
	}

}
